var struct__chan__par__t =
[
    [ "EbN0", "struct__chan__par__t.html#af3457e59e9d1d95e1b6d14ba79edb574", null ]
];