var struct__cc__encoder__info__t =
[
    [ "puncVect", "struct__cc__encoder__info__t.html#aaefa01529656ff6e8dd661e74758abd8", null ]
];