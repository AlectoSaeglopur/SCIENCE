var searchData=
[
  ['softdepuncturer_0',['SoftDepuncturer',['../convolutional_8c.html#a954fc9ed43766dcc8b6c6b062688ec89',1,'convolutional.c']]]
];
