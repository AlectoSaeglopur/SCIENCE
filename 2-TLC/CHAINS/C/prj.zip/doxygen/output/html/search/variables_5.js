var searchData=
[
  ['len_0',['len',['../struct__byte__stream__t.html#a0ace850f65d5318bf76fb93d5901e60b',1,'_byte_stream_t::len'],['../struct__float__stream__t.html#a0ace850f65d5318bf76fb93d5901e60b',1,'_float_stream_t::len'],['../struct__complex__stream__t.html#a0ace850f65d5318bf76fb93d5901e60b',1,'_complex_stream_t::len']]]
];
