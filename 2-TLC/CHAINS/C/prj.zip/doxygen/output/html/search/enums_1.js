var searchData=
[
  ['cc_5fdec_5fmethod_5ft_0',['cc_dec_method_t',['../convolutional_8h.html#ab6bf5dd3ca66fd4dcdb8839ae87fc113',1,'convolutional.h']]],
  ['cc_5fklen_5ft_1',['cc_klen_t',['../convolutional_8h.html#a38de18fffd75ccef7581a78855684da3',1,'convolutional.h']]],
  ['channel_5ft_2',['channel_t',['../channel_8h.html#a30e77e0b6fd428a0cceed4edb1ddbd20',1,'channel.h']]]
];
