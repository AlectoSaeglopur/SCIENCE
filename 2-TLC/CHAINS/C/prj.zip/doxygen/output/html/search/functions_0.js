var searchData=
[
  ['allocatebytestream_0',['AllocateByteStream',['../memory_8c.html#aa1c9d331f4ef452f6b20e66f3aa99946',1,'memory.c']]],
  ['allocatecomplexstream_1',['AllocateComplexStream',['../memory_8c.html#ab1b478a283c78e2c9a91f9d131155420',1,'memory.c']]],
  ['allocatefloatstream_2',['AllocateFloatStream',['../memory_8c.html#a2b475f7a8a1fecb1ff26d56c846b8a48',1,'memory.c']]]
];
