var searchData=
[
  ['retrieveconnectorpuncturationvectors_0',['RetrieveConnectorPuncturationVectors',['../convolutional_8c.html#a7c17cb69374a806e90867e6ddcaec177',1,'convolutional.c']]]
];
