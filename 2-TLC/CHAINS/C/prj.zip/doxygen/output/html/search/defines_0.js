var searchData=
[
  ['awgn_5febn0_0',['AWGN_EBN0',['../channel_8h.html#ab0291378557df7c7d9a287bc8b7ac523',1,'channel.h']]]
];
