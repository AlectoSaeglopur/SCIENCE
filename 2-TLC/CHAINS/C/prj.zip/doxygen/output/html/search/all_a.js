var searchData=
[
  ['klen_0',['kLen',['../struct__cc__par__t.html#a924a2177d10271f6b883f7c51f55a87b',1,'_cc_par_t']]]
];
