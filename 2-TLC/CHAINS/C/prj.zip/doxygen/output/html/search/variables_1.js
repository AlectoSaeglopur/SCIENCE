var searchData=
[
  ['dist_0',['dist',['../struct__cc__hard__dec__info__t.html#aa70d161c3fd98317d9bd09065c36c460',1,'_cc_hard_dec_info_t::dist'],['../struct__cc__soft__dec__info__t.html#aea474498accabd827f9b9be32dc1aa1f',1,'_cc_soft_dec_info_t::dist']]]
];
