var searchData=
[
  ['memfact_0',['memFact',['../struct__cc__par__t.html#abfd757054a6ded54f06b750de0c3b882',1,'_cc_par_t']]]
];
