var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "channel.c", "channel_8c.html", "channel_8c" ],
    [ "channel.h", "channel_8h.html", "channel_8h" ],
    [ "convolutional.c", "convolutional_8c.html", "convolutional_8c" ],
    [ "convolutional.h", "convolutional_8h.html", "convolutional_8h" ],
    [ "debug.c", "debug_8c.html", "debug_8c" ],
    [ "debug.h", "debug_8h.html", "debug_8h" ],
    [ "error.c", "error_8c.html", "error_8c" ],
    [ "error.h", "error_8h.html", "error_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "memory.c", "memory_8c.html", "memory_8c" ],
    [ "memory.h", "memory_8h_source.html", null ],
    [ "modulation.c", "modulation_8c.html", "modulation_8c" ],
    [ "modulation.h", "modulation_8h.html", "modulation_8h" ],
    [ "system.h", "system_8h.html", "system_8h" ]
];