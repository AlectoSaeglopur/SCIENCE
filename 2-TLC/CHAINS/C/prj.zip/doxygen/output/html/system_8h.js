var system_8h =
[
    [ "_complex_t", "struct__complex__t.html", "struct__complex__t" ],
    [ "BY2BI_SHIFT", "system_8h.html#a360ec061cb4ecdb30592495dc5bb54f9", null ],
    [ "byte_t", "system_8h.html#aed38f5b9e6bad674ac6ab6b0c40aa013", null ],
    [ "len_t", "system_8h.html#a144af81bf25f925e049eba389b5acda2", null ]
];