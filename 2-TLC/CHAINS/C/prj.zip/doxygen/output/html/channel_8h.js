var channel_8h =
[
    [ "_chan_par_t", "struct__chan__par__t.html", "struct__chan__par__t" ],
    [ "AWGN_EBN0", "channel_8h.html#ab0291378557df7c7d9a287bc8b7ac523", null ],
    [ "BSC_PEB", "channel_8h.html#a62adc672c4f93a9855b907dab925874d", null ],
    [ "CHAN_SEED", "channel_8h.html#aef22dad27cbfbf8d98d6fb044525ffb0", null ],
    [ "CHAN_TYPE", "channel_8h.html#a02ad48dad989be9466d6180ad89e387d", null ],
    [ "SEED2TIME", "channel_8h.html#a832309ce02c70c603d56ec709c529f1b", null ],
    [ "channel_t", "channel_8h.html#a30e77e0b6fd428a0cceed4edb1ddbd20", [
      [ "CHAN_BSC", "channel_8h.html#a30e77e0b6fd428a0cceed4edb1ddbd20a7d96892bb148fb58f6248f5e5d7f5490", null ],
      [ "CHAN_AWGN", "channel_8h.html#a30e77e0b6fd428a0cceed4edb1ddbd20a9499b84ff8af27271cd56f2753c3b5c1", null ],
      [ "CHAN_NUM", "channel_8h.html#a30e77e0b6fd428a0cceed4edb1ddbd20a50ccfbb19d46a65127a2f8c429e9eaec", null ]
    ] ],
    [ "Channel_AWGN", "channel_8h.html#a7fbdb35e62e6f7572b56acee57350263", null ],
    [ "Channel_BSC", "channel_8h.html#a447fb3627e3adb47767913e12783c552", null ],
    [ "Channel_ListParameters", "channel_8h.html#afd34dc089fd01a3617342289200cef93", null ]
];