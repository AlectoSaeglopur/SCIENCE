var group___t_l_c___c_h_a_i_n =
[
    [ "channel.c", "channel_8c.html", null ],
    [ "channel.h", "channel_8h.html", null ],
    [ "convolutional.c", "convolutional_8c.html", null ],
    [ "convolutional.h", "convolutional_8h.html", null ],
    [ "debug.c", "debug_8c.html", null ],
    [ "debug.h", "debug_8h.html", null ],
    [ "error.c", "error_8c.html", null ],
    [ "error.h", "error_8h.html", null ],
    [ "main.c", "main_8c.html", null ],
    [ "memory.c", "memory_8c.html", null ],
    [ "system.h", "system_8h.html", null ],
    [ "modulation.c", "modulation_8c.html", null ],
    [ "modulation.h", "modulation_8h.html", null ]
];