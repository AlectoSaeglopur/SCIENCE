var struct__float__stream__t =
[
    [ "id", "struct__float__stream__t.html#a4f594557c7bb22a63850dd55ce9a0bf6", null ],
    [ "len", "struct__float__stream__t.html#a0ace850f65d5318bf76fb93d5901e60b", null ]
];