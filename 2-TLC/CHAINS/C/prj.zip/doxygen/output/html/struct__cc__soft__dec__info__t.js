var struct__cc__soft__dec__info__t =
[
    [ "dist", "struct__cc__soft__dec__info__t.html#aea474498accabd827f9b9be32dc1aa1f", null ],
    [ "path", "struct__cc__soft__dec__info__t.html#ae87f5a1e9c81c570bf0635777aa33c54", null ]
];