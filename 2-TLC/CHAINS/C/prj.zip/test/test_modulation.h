
#ifndef TEST_MODULATION_H
#define	TEST_MODULATION_H

int run_modulation_tests(void);

#endif	
