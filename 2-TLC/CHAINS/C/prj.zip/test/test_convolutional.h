
#ifndef TEST_CONVOLUTIONAL_H
#define	TEST_CONVOLUTIONAL_H

int run_convolutional_tests(void);

#endif	
