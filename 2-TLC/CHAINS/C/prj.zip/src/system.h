/**
 * @file system.h
 * @author Filippo Valmori
 * @date 26/08/2024
 * @ingroup TLC_CHAIN
 * @brief System header
 * 
 * Header file containing project common libraries and definitions.
 */


#ifndef SYSTEM_H
#define SYSTEM_H


/****************/
/*** INCLUDES ***/
/****************/

#include <stdio.h>                                          /** - import standard i/o library */
#include <stdbool.h>                                        /** - import boolean type library */
#include <stdint.h>                                         /** - import integer types library */
#include <string.h>                                         /** - import string library (e.g. to use "memcpy" and "memset" functions) */
#include <stdlib.h>                                         /** - import random generation library */
#include <time.h>                                           /** - import time library (e.g. to link random seed to actual time) */
#include <math.h>                                           /** - import mathematical library (e.g. to use "sin/cos" and "log/exp" functions) */



/*****************/
/*** CONSTANTS ***/
/*****************/

#define BY2BI_SHIFT             3u                          //!< number of bit shifts to convert byte into bit value
#define BY2BI_LEN(x)            ((x)<<BY2BI_SHIFT)
#define BI2BY_LEN(x)            ((x)>>BY2BI_SHIFT)
#define MSBIT_MASK_U8           ((uint8_t) 0x80)
#define LSBIT_MASK_U8           ((uint8_t) 0x01)
#define MSBIT_MASK_U32          ((uint32_t) 0x80000000)
#define LSBYTE_MASK_U32         ((uint32_t) 0x00000007)
#define NUM_BITS_PER_BYTE       8u
#define BITIDX_1LAST            (NUM_BITS_PER_BYTE-1)
#define BITIDX_2LAST            (BITIDX_1LAST-1)
#define MATH_PI                 3.14159f
#define IS_EVEN(x)              (0 == ((x)%2))
#define IS_ODD(x)               (1 == ((x)%2))



/****************/
/*** TYPEDEFS ***/
/****************/

#define ulen_t                   uint32_t                   //!< bit/byte buffer length type (unsigned)
#define slen_t                  int32_t                     //!< bit/byte buffer length type (signed)
#define byte_t                  uint8_t                     //!< byte type

typedef struct _complex_t
{
  float re;                                                 /** - real part */
  float im;                                                 /** - imaginary part */
} complex_t;


#endif