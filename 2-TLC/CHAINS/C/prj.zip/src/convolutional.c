/**
 * @file convolutional.c
 * @author Filippo Valmori
 * @date 26/08/2024
 * @copyright Electrolux S.p.A.
 * @see Digital communications - Fundamentals and applications (Bernard Sklar, 2014)
 * @ingroup TLC_CHAIN
 * @brief Convolutional coding library
 * 
 * Library containing convolutional coding functions.
 */


/****************/
/*** INCLUDES ***/
/****************/

#include "convolutional.h"
#include "debug.h"



/*****************/
/*** CONSTANTS ***/
/*****************/

static const uint8_t CC_CVMATRIX[][CC_NBRANCHES] = {{7,5},{15,11},{23,25}, \
                                                    {47,53},{79,109},{159,229}};  /** Connector vectors for each K */

static const uint8_t CC_PUNC_VECT_23[] = {1,1,0,1};                               /** Puncturing vector for Rc = 2/3 */
static const uint8_t CC_PUNC_VECT_34[] = {1,1,0,1,1,0};                           /** Puncturing vector for Rc = 3/4 */
static const uint8_t CC_PUNC_VECT_56[] = {1,1,0,1,1,0,0,1,1,0};                   /** Puncturing vector for Rc = 5/6 */
static const uint8_t CC_PUNC_VECT_78[] = {1,1,0,1,0,1,0,1,1,0,0,1,1,0};           /** Puncturing vector for Rc = 7/8 */

const cc_rate_t CC_RATE_ARRAY[CC_RATE_NUM] =
{
  LIST_OF_CC_RATES(DEF_CC_RATES_ARRAY)
};



/**************************/
/*** PRIVATE PROTOTYPES ***/
/**************************/

static bool IsRateValid( cc_rate_t rateVal );
static bool IsKlenValid( cc_klen_t kVal );
static error_t RetrieveConnectorPuncturationVectors( cc_encoder_info_t * ioInfo, const cc_par_t * pParams );
static uint8_t ComputeEncBit( uint8_t cState, uint8_t cvVal, cc_klen_t kLen );
static error_t ComputeTrellisDiagram( cc_trellis_t * ioTrellisDiagr, const cc_encoder_info_t * encInfo, const cc_par_t * pParams );
static error_t HardDepuncturer( byte_t * ioBuffer, ulen_t inLenBi, ulen_t outLenBi, const uint8_t * punctVect, const cc_par_t * pParams );
static uint8_t CountByteOnes( byte_t InByte );
static uint8_t FindMinSurvPathHard( const cc_hard_dec_info_t * inPaths );
static error_t SoftDepuncturer( float * ioBuffer, ulen_t inLenBi, ulen_t outLenBi, const cc_encoder_info_t * encInfo, const cc_par_t * pParams );
static float EstimateEuclideanDist( const float * inBuf, uint8_t trlByte, uint8_t erasMask );
static uint8_t FindMinSurvPathSoft( const cc_soft_dec_info_t * inPaths);



/************************/
/*** PUBLIC FUNCTIONS ***/
/************************/

/**
 * @brief <i> Function for retrieving and listing convolution coding parameters into dedicated structure. </i>
 * 
 * @param[in] ioParams pointer to i/o parameters structure to be filled
 * 
 * @return error ID
 */
error_t CnvCod_ListParameters( cc_par_t * ioParams )
{
  Debug_SetWatermark((void *)CnvCod_ListParameters,WM_LEVEL_1);

  error_t retErr = ERR_NONE;

  if (NULL != ioParams)
  {
    ioParams->cRate = CC_RATE;
    ioParams->kLen = CC_KLEN;
    ioParams->memFact = CC_MEMFACT;
    ioParams->vitDM = CC_VITDM;
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for convolutional encoding (including puncturing). </i>
 * 
 * @param[in] inStream input stream
 * @param[out] outStream output stream
 * @param[in] pParams pointer to convolutional coding parameters structure
 * 
 * @return error ID
 */
error_t CnvCod_Encoder( const byte_stream_t * inStream, byte_stream_t * outStream, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)CnvCod_Encoder,WM_LEVEL_1);

  error_t retErr = ERR_NONE;
  const ulen_t unpLenBy = CC_NBRANCHES*inStream->len;                               /** - unpunctured coded length [B] */
  const ulen_t unpLenBi = BY2BI_LEN(unpLenBy);                                      /** - unpunctured coded length [b] */
  const ulen_t inLenBi = BY2BI_LEN(inStream->len);                                  /** - input buffer length [b] */
  const ulen_t punLenBi = inLenBi*(pParams->cRate+1)/pParams->cRate;                /** - expected punctured coded length [b] */
  const ulen_t punLenBy = BI2BY_LEN(punLenBi);                                      /** - expected punctured coded length [b] */
  cc_encoder_info_t encInfo;
  byte_stream_t tmpStream = {.len = unpLenBy, .id = memory_type_byte};
  ulen_t wrIdx = 0;
  ulen_t byteIdx;
  ulen_t j;
  uint8_t encState = 0;
  uint8_t bitIdx;
  uint8_t rdBit;
  uint8_t k;

  if (Memory_IsStreamValid(inStream,inStream->id) &&
      Memory_IsStreamValid(outStream,outStream->id) &&
      (NULL != pParams))
  {
    RetrieveConnectorPuncturationVectors(&encInfo,pParams);                         /** - retrieve convolutional encoder info */
    Memory_AllocateStream(&tmpStream,unpLenBy,memory_type_byte);

    if (punLenBy == outStream->len)
    {
      for (j=0; j<inLenBi; j++)
      {
        byteIdx = BI2BY_LEN(j)  ;                                                   /** - update byte index for reading input buffer */
        bitIdx = (uint8_t)(j&LSBYTE_MASK_U32);                                      /** - update bit index for reading input buffer */
        encState >>= 1;
        encState |= ((inStream->pBuf[byteIdx]>>(BITIDX_1LAST-bitIdx))&LSBIT_MASK_U8)
          <<(pParams->kLen-1);                                                      /** - update encoder state with latest input bit */
        byteIdx = BI2BY_LEN(CC_NBRANCHES*j);                                        /** - update byte index for output stream writing */
        bitIdx = (CC_NBRANCHES*j)&LSBYTE_MASK_U32;                                  /** - update bit index for output stream writing */

        for (k=0; k<CC_NBRANCHES; k++)
        {
          tmpStream.pBuf[byteIdx] |= (ComputeEncBit(encState,encInfo.pConnVect[k],
            pParams->kLen)<<(BITIDX_1LAST-k-bitIdx));
        }
      }

      if (CC_RATE_12 != pParams->cRate)
      {                                                                             /** - apply puncturing if selected Rc is higher than 1/2 */
        for (j=0; j<unpLenBi; j++)
        {
          byteIdx = BI2BY_LEN(j);
          bitIdx = j&LSBYTE_MASK_U32;
          rdBit = (tmpStream.pBuf[byteIdx]>>(BITIDX_1LAST-bitIdx))&LSBIT_MASK_U8;   /** - j-th bit of unpunctured output stream */
          if (encInfo.pPuncVect[j%(encInfo.lenPuncVect*pParams->cRate)])            /** - check if puncturation has to applied now */
          {
            byteIdx = BI2BY_LEN(wrIdx);
            bitIdx = BITIDX_1LAST-(uint8_t)(wrIdx&LSBYTE_MASK_U32);
            wrIdx++;
            if (0 == rdBit)
            {
              tmpStream.pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<bitIdx);
            }
            else
            {
              tmpStream.pBuf[byteIdx] |= (LSBIT_MASK_U8<<bitIdx);
            }
          }
        }

        if (punLenBi != wrIdx)                                                      /** - check if computed and theoretical punctured length match */
        {
          retErr = ERR_INV_BUFFER_SIZE;
        }
      }

      if (ERR_NONE == retErr)
      {
        memcpy(outStream->pBuf,tmpStream.pBuf,outStream->len);                      /** - copy temporary buffer content to output one */
      }
    }
    else
    {
      retErr = ERR_INV_BUFFER_SIZE;
    }

    Memory_FreeStream(&tmpStream,memory_type_byte);
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }
  
   return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for convolutional hard-decoding by implementing Viterbi algorithm (including depuncturing). </i>
 * 
 * @param[in] inStream input stream
 * @param[out] outStream output stream
 * @param[in] pParams pointer to convolutional coding parameters structure
 * 
 * @return error ID
 */
error_t CnvCod_HardDecoder( const byte_stream_t * inStream, byte_stream_t * outStream, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)CnvCod_HardDecoder,WM_LEVEL_1);

  error_t retErr = ERR_NONE;
  const ulen_t outLenBi = BY2BI_LEN(outStream->len);
  const ulen_t inLenBi = BY2BI_LEN(inStream->len);
  const ulen_t unpLenBy = CC_NBRANCHES*inStream->len*pParams->cRate/(pParams->cRate+1);
  const ulen_t unpLenBi = BY2BI_LEN(unpLenBy);
  cc_encoder_info_t encInfo;
  cc_hard_dec_info_t curPaths = {.iter={0}, .dist={0}, .path={{0}}};
  cc_hard_dec_info_t prevPaths;
  cc_trellis_t trDiagr;
  uint32_t byteIdx, inIdx, wrIdx, finIdx;
  uint32_t candDist;
  uint32_t i;
  uint8_t tmpStream[unpLenBy];
  uint8_t nextSt, minDistSt, depSt, arrSt;
  uint8_t bitIdx, hypIdx;
  uint8_t cycleBits;
  uint8_t hamDist;
  uint8_t erasMask;
  uint8_t j;
  
  if (Memory_IsStreamValid(inStream,inStream->id) && 
      Memory_IsStreamValid(outStream,outStream->id) &&
      (NULL != pParams))
  {
    if (CC_VITDM_HARD == pParams->vitDM)
    {
      RetrieveConnectorPuncturationVectors(&encInfo,pParams);                                     /** - retrieve convolutional encoder info */
      ComputeTrellisDiagram(&trDiagr,&encInfo,pParams);                                           /** - compute convolutional decoder trellis diagram */
      memcpy(tmpStream,inStream->pBuf,inStream->len);
      curPaths.iter[0] = 1;                                                                       /** - enable only all-zero state at the beginning */

      if (CC_RATE_12 == pParams->cRate)                                                           /** - check if depuncturing is needed */
      {
        erasMask = CC_INMASK;                                                                     /** - use no-erasure mask for no-puncturing case */
      }
      else
      {
        HardDepuncturer(tmpStream,inLenBi,unpLenBi,encInfo.pPuncVect,pParams);
      }

      for (i=CC_NBRANCHES; i<outLenBi+CC_NBRANCHES; i++)
      {
        inIdx = CC_NBRANCHES*(i-CC_NBRANCHES);
        byteIdx = BI2BY_LEN(inIdx);
        bitIdx = (uint8_t)(inIdx&LSBYTE_MASK_U32);
        cycleBits = (tmpStream[byteIdx]>>(BITIDX_2LAST-bitIdx))&CC_INMASK;                        /** - current pair of input bits */
        prevPaths = curPaths;
        if (CC_RATE_12 != pParams->cRate)                                                         /** - retrieve erasure mask in case depuncturing has been applied */
        {
          erasMask = 0;
          erasMask |= (encInfo.pPuncVect[inIdx%(CC_NBRANCHES*pParams->cRate)]<<1);
          erasMask |= encInfo.pPuncVect[(inIdx+1)%(CC_NBRANCHES*pParams->cRate)];
        }
        for (j=0; j<CC_NTRELSTATES; j++)
        {
          if (prevPaths.iter[j] == i-1)                                                           /** check if j-th state was active in previous iteration */
          {                                                          
            for (hypIdx = 0; hypIdx<CC_NBRANCHES; hypIdx++)
            {
              hamDist = CountByteOnes((cycleBits^(trDiagr.trSt[j].outBits[hypIdx]))&erasMask);    /** compute Hamming distance assuming hypIdx input bit */
              nextSt = trDiagr.trSt[j].nextSt[hypIdx];                                            /** compute next state assuming hypIdx input bit */
              if (curPaths.iter[nextSt] < i)                                                      /** if there's not yet a survivor path for nextSt state at i-th cycle */
              {
                curPaths.iter[nextSt] = i;                                                        /** update state iteration counter */
                curPaths.dist[nextSt] = prevPaths.dist[j]+(uint32_t)hamDist;                      /** update state distance */
                if (i-1 < CC_MEM_DIM)
                {
                  finIdx = i-CC_NBRANCHES;
                }
                else
                {
                  finIdx = CC_MEM_DIM-1;
                }
                for (wrIdx = 0; wrIdx < finIdx; wrIdx++)                                          /** update state path among previous states */
                {
                  curPaths.path[nextSt][wrIdx] = prevPaths.path[j][wrIdx];
                }
                curPaths.path[nextSt][finIdx] = j;              
              }
              else                                                                                /** if a survivor path for nextSt state at i-th cycle already exists, check if new candidate is better */
              {
                candDist = prevPaths.dist[j]+(uint32_t)hamDist;
                if (candDist < curPaths.dist[nextSt])
                {
                  curPaths.dist[nextSt] = candDist;
                  if (i-1 < CC_MEM_DIM)
                  {
                    finIdx = i-CC_NBRANCHES;
                  }
                  else
                  {
                    finIdx = CC_MEM_DIM-1;
                  }
                  for (wrIdx = 0; wrIdx < finIdx; wrIdx++)
                  {
                    curPaths.path[nextSt][wrIdx] = prevPaths.path[j][wrIdx];
                  }
                  curPaths.path[nextSt][finIdx] = j;
                }
              }
            }
          }
        }

        if (i-1 == outLenBi)                                                                      /** - if input bit stream is over, flush decoder memory and extract final info bits */
        {
          minDistSt = FindMinSurvPathHard(&curPaths);                                             /** look for minimum distance survivor path */
          if (i-1 >= CC_MEM_DIM)                                                                  /** check if memory has been completely filled */
          {
            finIdx = CC_MEM_DIM;
          }
          else
          {
            finIdx = i-1;
          }
          for (wrIdx=0; wrIdx<finIdx; wrIdx++)
          {
            depSt = curPaths.path[minDistSt][wrIdx];                                              /** set departure state */
            if (wrIdx == finIdx-1)
            {
              arrSt = minDistSt;                                                                  /** set arrival state */
            }
            else
            {
              arrSt = curPaths.path[minDistSt][wrIdx+1];
            }
            byteIdx = BI2BY_LEN(outLenBi-finIdx+wrIdx);
            bitIdx = (uint8_t)((outLenBi-finIdx+wrIdx)&LSBYTE_MASK_U32);
            if (trDiagr.trSt[depSt].nextSt[0] == arrSt)
            {
              outStream->pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                /** set output bit to '0' */
            }
            else
            {
              outStream->pBuf[byteIdx] |= (LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                 /** set output bit to '1' */
            }
          }
        }
        else if (i-1 >= CC_MEM_DIM)                                                               /** - if input bit stream is not over but memory is full, extract oldest info bit */
        {
          minDistSt = FindMinSurvPathHard(&curPaths);
          depSt = curPaths.path[minDistSt][0];
          arrSt = curPaths.path[minDistSt][1];
          byteIdx = BI2BY_LEN(i-CC_MEM_DIM-1);
          bitIdx = (uint8_t)((i-CC_MEM_DIM-1)&LSBYTE_MASK_U32);
          if (trDiagr.trSt[depSt].nextSt[0] == arrSt)
          {
            outStream->pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));
          }
          else
          {
            outStream->pBuf[byteIdx] |= (LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));
          }
          for (j=0; j<CC_NTRELSTATES; j++)
          {
            for (wrIdx = 0; wrIdx<(CC_MEM_DIM-1); wrIdx++)
            {
              curPaths.path[j][wrIdx] = curPaths.path[j][wrIdx+1];                                /** - keep all survivor paths */
            }
          }
        }
      }
    }
    else
    {
      retErr = ERR_INV_CNVCOD_DECMET;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }
  
  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for convolutional soft-decoding by implementing Viterbi algorithm (including depuncturing). </i>
 * 
 * @param[in] inStream input stream
 * @param[out] outStream output stream
 * @param[in] pParams pointer to convolutional coding parameters structure
 * 
 * @return error ID
 */
error_t CnvCod_SoftDecoder( const float_stream_t * inStream, byte_stream_t * outStream, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)CnvCod_SoftDecoder,WM_LEVEL_1);

  error_t retErr = ERR_NONE;
  const ulen_t outLenBi = BY2BI_LEN(outStream->len);
  const ulen_t unpLenBi = CC_NBRANCHES*outLenBi;
  const ulen_t punLenBi = inStream->len;
  float tmpStream[unpLenBi];
  cc_soft_dec_info_t curPaths = {.iter={0}, .dist={0.0}, .path={{0}}};
  cc_soft_dec_info_t prevPaths;
  cc_encoder_info_t encInfo;
  cc_trellis_t trDiagr;
  float eucliDist, candDist;
  ulen_t curIdx, wrIdx, finIdx;
  ulen_t byteIdx;
  ulen_t i;
  uint8_t nextSt, minDistState;
  uint8_t stateDep, stateArr;
  uint8_t j, bitIdx, hypIdx;
  uint8_t erasMask;

  if (Memory_IsStreamValid(inStream,inStream->id) &&
      Memory_IsStreamValid(outStream,outStream->id) &&
      (NULL != pParams))
  {
    if (CC_VITDM_SOFT == pParams->vitDM)
    {
      RetrieveConnectorPuncturationVectors(&encInfo,pParams);                                     /** - retrieve convolutional encoder info */
      ComputeTrellisDiagram(&trDiagr,&encInfo,pParams);                                           /** - compute convolutional decoder trellis diagram */
      memcpy(tmpStream,inStream->pBuf,sizeof(float)*inStream->len);
      curPaths.iter[0] = 1;                                                                       /** - enable only the all-zero state at the beginning */

      if (CC_RATE_12 == pParams->cRate)
      {
        erasMask = CC_INMASK;                                                                     /** - use no-erasure mask for no-puncturing case */
      }
      else
      {
        SoftDepuncturer(tmpStream,punLenBi,unpLenBi,&encInfo,pParams);                            /** - apply depuuncturing if needed */
      }

      for (i=CC_NBRANCHES; i<outLenBi+CC_NBRANCHES; i++)
      {
        curIdx = CC_NBRANCHES*(i-CC_NBRANCHES);
        prevPaths = curPaths;

        if (CC_RATE_12 != pParams->cRate)
        {
          erasMask = 0;
          erasMask |= (encInfo.pPuncVect[curIdx%(CC_NBRANCHES*pParams->cRate)]<<1);
          erasMask |= encInfo.pPuncVect[(curIdx+1)%(CC_NBRANCHES*pParams->cRate)];                /** - estimate specific erasure mask if depuncturing has been applied */
        }

        for (j=0; j<CC_NTRELSTATES; j++)
        {
          if (prevPaths.iter[j] == i-1)                                                           /** - check if j-th state was active in the previous iteration */
          {
            for (hypIdx = 0; hypIdx<CC_NBRANCHES; hypIdx++)
            {
              eucliDist = EstimateEuclideanDist(&tmpStream[curIdx],
                            trDiagr.trSt[j].outBits[hypIdx],erasMask);                            /** compute Euclidean distance assuming hypIdx-value input bit */
              nextSt = trDiagr.trSt[j].nextSt[hypIdx];                                            /** compute trellis next state assuming hypIdx-value input bit */

              if (curPaths.iter[nextSt] < i)                                                      /** iIf there's not yet a survivor path for nextSt state at i-th cycle */
              {
                curPaths.iter[nextSt] = i;                                                        /** update the state iteration counter */
                curPaths.dist[nextSt] = prevPaths.dist[j]+eucliDist;                              /** update the state distance */
                if (i-1 < CC_MEM_DIM)
                {
                  finIdx = i-CC_NBRANCHES;
                }
                else
                {
                  finIdx = CC_MEM_DIM-1;
                }
                for (wrIdx = 0; wrIdx < finIdx; wrIdx++)                                          /** update the state path among previous states */
                {
                  curPaths.path[nextSt][wrIdx] = prevPaths.path[j][wrIdx];
                }
                curPaths.path[nextSt][finIdx] = j;
              }
              else                                                                                /** if a survivor path for nextSt state at i-th cycle already exists, check if the new candidate is better */
              {
                candDist = prevPaths.dist[j]+eucliDist;
                if (candDist < curPaths.dist[nextSt])
                {
                  curPaths.dist[nextSt] = candDist;
                  if (i-1 < CC_MEM_DIM)
                  {
                    finIdx = i-CC_NBRANCHES;
                  }
                  else
                  {
                    finIdx = CC_MEM_DIM-1;
                  }
                  for (wrIdx = 0; wrIdx < finIdx; wrIdx++)
                  {
                    curPaths.path[nextSt][wrIdx] = prevPaths.path[j][wrIdx];
                  }
                  curPaths.path[nextSt][finIdx] = j;
                }
              }
            }
          }
        }

        if (outLenBi == i-1)                                                                      /** - if input bit stream is over, flush the decoder memory and extract the final info bits */
        {
          minDistState = FindMinSurvPathSoft(&curPaths);                                          /** look for the minimum distance survivor path */
          if (i-1 >= CC_MEM_DIM)                                                                  /** check if memory has been completely filled */
          {
            finIdx = CC_MEM_DIM;
          }
          else
          {
            finIdx = i-1;
          }
          for (wrIdx=0; wrIdx<finIdx; wrIdx++)
          {
            stateDep = curPaths.path[minDistState][wrIdx];                                        /** departure state */
            if (wrIdx == finIdx-1)
            {
              stateArr = minDistState;                                                            /** arrival state */
            }
            else
            {
              stateArr = curPaths.path[minDistState][wrIdx+1];
            }
            byteIdx = BI2BY_LEN(outLenBi-finIdx+wrIdx);
            bitIdx = (outLenBi-finIdx+wrIdx)&LSBYTE_MASK_U32;
            if (trDiagr.trSt[stateDep].nextSt[0] == stateArr)
            {
              outStream->pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                /** set output bit to '0' */
            }
            else
            {
              outStream->pBuf[byteIdx] |= (LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                 /** set output bit to '1' */
            }
          }
        }
        else if (i-1 >= CC_MEM_DIM)                                                               /** - if input bit stream is not over but memory is full, extract the oldest info bit */
        {
          minDistState = FindMinSurvPathSoft(&curPaths);
          stateDep = curPaths.path[minDistState][0];
          stateArr = curPaths.path[minDistState][1];
          byteIdx = BI2BY_LEN(i-CC_MEM_DIM-1);
          bitIdx = (uint8_t)((i-CC_MEM_DIM-1)&LSBYTE_MASK_U32);
          if (trDiagr.trSt[stateDep].nextSt[0] == stateArr)
          {
            outStream->pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                  /** - set output bit to '0' */
          }
          else
          {
            outStream->pBuf[byteIdx] |= (LSBIT_MASK_U8<<(BITIDX_1LAST-bitIdx));                   /** - set output bit to '1' */
          }
          for (j=0; j<CC_NTRELSTATES; j++)
          {
            for (wrIdx = 0; wrIdx<(CC_MEM_DIM-1); wrIdx++)
            {
              curPaths.path[j][wrIdx] = curPaths.path[j][wrIdx+1];                                /** - keep all survivor paths */
            }
          }
        }
      }
    }
    else
    {
      retErr = ERR_INV_CNVCOD_DECMET;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}



/*************************/
/*** PRIVATE FUNCTIONS ***/
/*************************/

/**
 * @brief <i> Function for retrieving connection and puncturation vectors as a function of the selected parameters. </i>
 * 
 * @param[out] ioInfo pointer to i/o structure to be filled
 * @param[in] pParams pointer to convolutional coding parameters structure
 * 
 * @return error ID
 */
static error_t RetrieveConnectorPuncturationVectors( cc_encoder_info_t * ioInfo, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)RetrieveConnectorPuncturationVectors,WM_LEVEL_2);

  error_t retErr = ERR_NONE;

  if ((NULL != ioInfo) && (NULL != pParams))
  {
    if (IsKlenValid(pParams->kLen))
    {
      ioInfo->pConnVect = CC_CVMATRIX[pParams->kLen-CC_KLEN_MIN];                                 /** - link connector vector */
      ioInfo->lenConnVect = CC_NBRANCHES;
    }
    else
    {
      retErr = ERR_INV_CNVCOD_KLEN;
    }

    if (IsRateValid(pParams->cRate))
    {
      switch (pParams->cRate)
      {
        case CC_RATE_23:
          ioInfo->pPuncVect = CC_PUNC_VECT_23;
          ioInfo->lenPuncVect = sizeof(CC_PUNC_VECT_23);                                          /** - link puncturation vector */                         
          break;
        
        case CC_RATE_34:
          ioInfo->pPuncVect = CC_PUNC_VECT_34;
          ioInfo->lenPuncVect = sizeof(CC_PUNC_VECT_34);
          break;

        case CC_RATE_56:
          ioInfo->pPuncVect = CC_PUNC_VECT_56;
          ioInfo->lenPuncVect = sizeof(CC_PUNC_VECT_56);
          break;

        case CC_RATE_78:
          ioInfo->pPuncVect = CC_PUNC_VECT_78;
          ioInfo->lenPuncVect = sizeof(CC_PUNC_VECT_78);
          break;

        default:
          // do nothing
          break;
      }
    }
    else
    {
      retErr = ERR_INV_CNVCOD_RATE;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for checking the correctness of code rate parameter. </i>
 * 
 * @param[in] rateVal code rate value
 * 
 * @return validity outcome
 */
static bool IsRateValid( cc_rate_t rateVal )
{
  Debug_SetWatermark((void *)IsRateValid,WM_LEVEL_2);

  bool bRet = false;
  uint8_t j;

  for (j=0; j<CC_RATE_NUM; j++)
  {
    if (rateVal == CC_RATE_ARRAY[j])
    {
      bRet = true;
      break;
    }
  }

  return bRet;
}


/**
 * @brief <i> Function for checking the correctness of the constraint length parameter. </i>
 * 
 * @param[in] kVal constraint length value
 * 
 * @return validity outcome
 */
static bool IsKlenValid( cc_klen_t kVal )
{
  Debug_SetWatermark((void *)IsKlenValid,WM_LEVEL_2);

  bool bRet;

  bRet = (kVal >= CC_KLEN_MIN) && (kVal <= CC_KLEN_MAX);

  return bRet;
}


/**
 * @brief <i> Function for computing the next encoded bit. </i>
 * 
 * @param[in] cState current convolutional state
 * @param[in] cvVal connection vector value
 * @param[in] kLen encoder constraint length
 * 
 * @return next encoded bit
 */
static uint8_t ComputeEncBit( uint8_t cState, uint8_t cvVal, cc_klen_t kLen )
{
  Debug_SetWatermark((void *)ComputeEncBit,WM_LEVEL_3);

  uint8_t outBit = 0;
  uint8_t j;

  for (j=0; j<kLen; j++)
  {
    outBit ^= (((cState>>j)&LSBIT_MASK_U8)&((cvVal>>j)&LSBIT_MASK_U8));
  }

  return outBit;
}


/**
 * @brief <i> Function for retrieving depunctured trellis diagram information. </i>
 * 
 * @param[out] ioTrellisDiagr pointer to trellis structure to be filled
 * @param[in] encInfo pointer to encoder info structure
 * @param[in] pParams pointer to parameters structure
 * 
 * @return error ID
 */
static error_t ComputeTrellisDiagram( cc_trellis_t * ioTrellisDiagr, const cc_encoder_info_t * encInfo, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)ComputeTrellisDiagram,WM_LEVEL_2);

  error_t retErr = ERR_NONE;
  uint8_t StBin[CC_NTRELSTATES];
  uint8_t i, j;
  uint8_t outBit;
  uint8_t state0, state1;
  
  if (NULL != ioTrellisDiagr)
  {
    for (j=0; j<CC_NTRELSTATES; j++)
    {
      StBin[j] = j;                                                                               /** - state IDs */
    }
    for (j=0; j<CC_NTRELSTATES; j++)
    {
      state0 = StBin[j];                                                                          /** - state update due to new 0-bit input */
      for (i=0; i<encInfo->lenConnVect; i++)
      {
        outBit = ComputeEncBit(state0,encInfo->pConnVect[i],pParams->kLen);                       /** estimate encoded bit from i-th connection branch */
        if ( 0 == i)
        {
          ioTrellisDiagr->trSt[j].outBits[0] = outBit<<1;                                         /** store 1st encoded bit into trellis */
        }
        else
        {
          ioTrellisDiagr->trSt[j].outBits[0] += outBit;                                           /** store 2nd encoded bit into trellis */
        }
      }
      ioTrellisDiagr->trSt[j].nextSt[0] = state0>>1;                                              /** - store next state into trellis (due to 0-bit input from j-th state) */
      state1 = state0|(LSBIT_MASK_U8<<(pParams->kLen-1));                                         /** - state update due to new 1-bit input */
      for (i=0; i<encInfo->lenConnVect; i++)
      {
        outBit = ComputeEncBit(state1,encInfo->pConnVect[i],pParams->kLen);
        if (0 == i)
        {
          ioTrellisDiagr->trSt[j].outBits[1] = outBit<<1;
        }
        else
        {
          ioTrellisDiagr->trSt[j].outBits[1] += outBit;
        }
      }
      ioTrellisDiagr->trSt[j].nextSt[1] = state1>>1;                                              /** - store next state into trellis (due to 1-bit input from j-th state) */
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function to hard-depuncture a byte stream to base code rate. </i>
 * 
 * @param[in, out] ioBuffer i/o buffer
 * @param[in] inLenBi input length [b]
 * @param[in] outLenBi output length [b]
 * @param[in] punctVect puncturing vector
 * @param[in] pParams coding parameters
 * 
 * @return error ID
 */
static error_t HardDepuncturer( byte_t * ioBuffer, ulen_t inLenBi, ulen_t outLenBi, const uint8_t * punctVect, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)HardDepuncturer,WM_LEVEL_2);

  error_t retErr = ERR_NONE;
  uint32_t rdIdx = inLenBi-1;                                                                     /** - final bit index of input stream length */
  uint32_t byteIdx;
  uint32_t j;
  uint8_t rdIdxPunc = CC_NBRANCHES*pParams->cRate-1;
  uint8_t bitIdx;
  uint8_t rdBit;

  if (NULL != ioBuffer)
  {
    for (j=outLenBi; j>0; j--)
    {
      if (1 == punctVect[rdIdxPunc])
      {
        byteIdx = BI2BY_LEN(rdIdx);
        bitIdx = (uint8_t)(BITIDX_1LAST-(rdIdx&LSBYTE_MASK_U32));
        rdBit = ioBuffer[byteIdx]&(LSBIT_MASK_U8<<bitIdx);
        rdIdx--;
      }
      else
      {
        rdBit = 0;                                                                                /** - each erasure bit restored has '0' value */
      }
      if (rdIdxPunc > 0)
      {
        rdIdxPunc--;
      }
      else
      {
        rdIdxPunc = CC_NBRANCHES*pParams->cRate-1;
      }
      byteIdx = BI2BY_LEN(j-1);
      bitIdx = (uint8_t)(BITIDX_1LAST-((j-1)&LSBYTE_MASK_U32));
      if (0 == rdBit)
      {
        ioBuffer[byteIdx] &= ~(LSBIT_MASK_U8<<bitIdx);                                            /** - set output bit to '0' */
      }
      else
      {
        ioBuffer[byteIdx] |= (LSBIT_MASK_U8<<bitIdx);                                             /** - set output bit to '1' */
      }
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for counting the number of 1-bits within the input byte. </i>
 * 
 * @param[in] inByte input byte
 * 
 * @return number of '1's
 */
static uint8_t CountByteOnes( byte_t inByte )
{
  Debug_SetWatermark((void *)CountByteOnes,WM_LEVEL_3);

  uint8_t j;
  uint8_t cnt = 0;

  for (j=0; j<NUM_BITS_PER_BYTE; j++)
  {
    if ((inByte>>j)&LSBIT_MASK_U8)
    {
      cnt++;
    }
  }
  
  return cnt;
}


/**
 * @brief <i> Function to find the hard survivor path with minimum distance. </i>
 * 
 * @param[in] inPaths current Viterbi paths
 * 
 * @return index of minimum distance trellis state
 */
static uint8_t FindMinSurvPathHard( const cc_hard_dec_info_t * inPaths )
{
  Debug_SetWatermark((void *)FindMinSurvPathHard,WM_LEVEL_3);

  uint32_t minDist;
  uint8_t minStateIdx;
  uint8_t j;
  
  if (NULL != inPaths)
  {
    minDist = inPaths->dist[0];
    minStateIdx = 0;
    for (j=1; j<CC_NTRELSTATES; j++)
    {
      if ((inPaths->iter[j]>0) && (inPaths->dist[j] < minDist))
      {
        minDist = inPaths->dist[j];
        minStateIdx = j;
      }
    }
  }

  return minStateIdx;
}


/**
 * @brief <i> Function to soft-depuncture an LLR stream to base code rate. </i>
 * 
 * @param[in, out] ioBuffer i/o buffer
 * @param[in] inLenBi input length [b]
 * @param[in] outLenBi output length [b]
 * @param[in] encInfo pointer to encoder info structure
 * @param[in] pParams coding parameters
 * 
 * @return error ID
 */
static error_t SoftDepuncturer( float * ioBuffer, ulen_t inLenBi, ulen_t outLenBi, const cc_encoder_info_t * encInfo, const cc_par_t * pParams )
{
  Debug_SetWatermark((void *)SoftDepuncturer,WM_LEVEL_2);

  error_t retErr = ERR_NONE;
  ulen_t i = inLenBi-1;                                                                           /** - reading index over LLR array */
  ulen_t j;
  uint8_t k = encInfo->lenPuncVect-1;                                                             /** - reading index within punturing vector */
  
  if (NULL != ioBuffer)
  {
    for (j=outLenBi; j>0; j--)
    {
      if (1 == encInfo->pPuncVect[k])
      {
        ioBuffer[j-1] = ioBuffer[i];
        i--;
      }
      else
      {
        ioBuffer[j-1] = 0;                                                                        /** - each erasure LLR restored has 0-value */
      }
      if (k > 0)
      {
        k--;
      }
      else
      {
        k = CC_NBRANCHES*pParams->cRate-1;
      }
    }

  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for calculating Euclidean distance between LLR values and specific trellis state. </i>
 * 
 * @param[in] inBuf input LLR buffer
 * @param[in] trlByte output bits for specific trellis state
 * @param[in] erasMask depuncturing erasure mask
 * 
 * @return estimated Euclidean distance
 */
static float EstimateEuclideanDist( const float * inBuf, uint8_t trlByte, uint8_t erasMask )
{
  Debug_SetWatermark((void *)EstimateEuclideanDist,WM_LEVEL_3);

  uint8_t j;
  float Dist = 0;

  if (NULL != inBuf)
  {
    for (j=0; j<CC_NBRANCHES; j++)
    {
      if ((erasMask>>(1-j))&LSBIT_MASK_U8)
      {
        Dist += fabs(CC_NBRANCHES*((float)((trlByte>>(1-j))&LSBIT_MASK_U8))-1-inBuf[j]);
      }
    }
  }
  
  return Dist;
}


/**
 * @brief <i> Function to find the soft survivor path with minimum distance. </i>
 * 
 * @param[in] InPaths current Viterbi paths
 * 
 * @return index of minimum distance trellis state
 */
static uint8_t FindMinSurvPathSoft( const cc_soft_dec_info_t * inPaths)
{
  Debug_SetWatermark((void *)FindMinSurvPathSoft,WM_LEVEL_3);

  float minDist;
  uint8_t minStIdx;
  uint8_t j;

  if (NULL != inPaths)
  {
    minDist = inPaths->dist[0];
    minStIdx = 0;
    for (j=1; j<CC_NTRELSTATES; j++)
    {
      if ((inPaths->iter[j]>0) && (inPaths->dist[j]<minDist))
      {
        minDist = inPaths->dist[j];
        minStIdx = j;
      }
    }
  }

  return minStIdx;
}



/**********************/
/*** TEST FUNCTIONS ***/
/**********************/

#ifdef UTEST

uint8_t Test_CountByteOnes( byte_t inByte )
{
  return CountByteOnes(inByte);
}

#endif
