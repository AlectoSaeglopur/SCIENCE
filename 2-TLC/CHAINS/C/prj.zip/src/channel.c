/**
 * @file channel.c
 * @author Filippo Valmori
 * @date 26/08/2024
 * @copyright Electrolux S.p.A.
 * @see Digital communications - Fundamentals and applications (Bernard Sklar, 2014)
 * @ingroup TLC_CHAIN
 * @brief Channel library
 * 
* Library containing channel functions.
 */


/****************/
/*** INCLUDES ***/
/****************/

#include "channel.h"
#include "debug.h"
#include "modulation.h"



/**************************/
/*** PRIVATE PROTOTYPES ***/
/**************************/

static float GetComplexSgnPower( const complex_stream_t * inStream );



/************************/
/*** PUBLIC FUNCTIONS ***/
/************************/

/**
 * @brief <i> Function for retrieving and listing channel parameters into dedicated structure. </i>
 * 
 * @param[out] ioParams pointer to i/o parameters structure to be filled
 * 
 * @return error ID
 */
error_t Channel_ListParameters( chan_par_t * ioParams )
{
  Debug_SetWatermark((void *)Channel_ListParameters,WM_LEVEL_1);

  error_t retErr = ERR_NONE;

  if (NULL != ioParams)
  {
    ioParams->type = CHAN_TYPE;
    ioParams->bps = MOD_BPS;
    ioParams->seed = CHAN_SEED;

    if (CHAN_BSC == ioParams->type)
    {
      ioParams->Peb = BSC_PEB;
    }
    else
    {
      ioParams->EbN0 = AWGN_EBN0;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for applying Binary Symmetric Channel (BSC) corruption. </i>
 * 
 * @param[in] inStream input stream
 * @param[out] outStream output stream
 * @param[in] pParams poiter to channel parameters structure
 * 
 * @return error ID
 */
error_t Channel_BSC( const byte_stream_t * inStream, byte_stream_t *outStream, const chan_par_t * pParams )
{
  Debug_SetWatermark((void *)Channel_BSC,WM_LEVEL_1);

  error_t retErr = ERR_NONE;
  ulen_t j;
  ulen_t byteIdx;
  uint8_t bitIdx;

  if (Memory_IsStreamValid(inStream,inStream->id) &&
      Memory_IsStreamValid(outStream,outStream->id) &&
      (NULL != pParams))
  {
    if (inStream->len == outStream->len)
    {
      if (CHAN_BSC == pParams->type)
      {
        memcpy(outStream->pBuf,inStream->pBuf,inStream->len);
        if (SEED2TIME == pParams->seed)
        {
          srand(time(NULL));                                          /** - link random seed to current time */
        }
        else
        {
          srand(pParams->seed);                                       /** - link random seed to provided argument */
        }
        for (j=0; j<inStream->len; j++)
        {
          if ((float)rand()/RAND_MAX < pParams->Peb)
          {
            byteIdx = BI2BY_LEN(j);
            bitIdx  = BITIDX_1LAST-(uint8_t)(j&LSBYTE_MASK_U32);
            if (outStream->pBuf[byteIdx] & (LSBIT_MASK_U8<<bitIdx))
            {
              outStream->pBuf[byteIdx] &= ~(LSBIT_MASK_U8<<bitIdx);
            }
            else
            {
              outStream->pBuf[byteIdx] |= (LSBIT_MASK_U8<<bitIdx);
            }
          }
        }
      }
      else
      {
        retErr = ERR_INV_CHANNEL_TYPE;
      }
    }
    else
    {
      retErr = ERR_INV_BUFFER_SIZE;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}


/**
 * @brief <i> Function for applying Additive White Gaussian Noise (AWGN) corruption based on Box-Muller method. </i>
 * 
 * @param[in] inStream input stream
 * @param[out] outStream output stream
 * @param[in] pParams poiter to channel parameters structure
 * 
 * @return error ID
 */
error_t Channel_AWGN( const complex_stream_t * inStream, complex_stream_t * outStream, const chan_par_t * pParams )
{
  Debug_SetWatermark((void *)Channel_AWGN,WM_LEVEL_1);

  error_t retErr = ERR_NONE;
  const float mu = 0;                                                 /** - noise mean value */
  const float sgnPwr = GetComplexSgnPower(inStream);                  /** - signal average power [lin] */
  const float SNR = pParams->EbN0+10*log10(pParams->bps);             /** - signal-to-noise-ratio [dB] */
  const float SqSigma = sgnPwr*pow(10,-SNR/10);                       /** - target noise variance (N0) */
  float nU1, nU2;                                                     /** - random variables uniformly distributed between 0 and 1 */
  float nReN, nIm;                                                    /** - random variables normally distributed as Mu|Sigma2 */
  ulen_t j;

  if (Memory_IsStreamValid(inStream,inStream->id) &&
      Memory_IsStreamValid(outStream,outStream->id) &&
      (NULL != pParams))
  {
    if (inStream->len == outStream->len)
    {
      if (CHAN_AWGN == pParams->type)
      {
        memcpy(outStream->pBuf,inStream->pBuf,sizeof(complex_t)*inStream->len);
        if (SEED2TIME == pParams->seed)
        {
          srand(time(NULL));                                          /** - link random seed to current time */
        }
        else
        {
          srand(pParams->seed);                                       /** - link random seed to provided argument */
        }
        for (j=0; j<inStream->len; j++)
        {    
          nU1 = rand()*(1.0/RAND_MAX);
          nU2 = rand()*(1.0/RAND_MAX);
          nReN = sqrt(-2*log(nU1))*cos(2*MATH_PI*nU2)*sqrt(SqSigma/2)+mu;
          nIm = sqrt(-2*log(nU1))*sin(2*MATH_PI*nU2)*sqrt(SqSigma/2)+mu;
          if ((INFINITY != fabs(nReN)) && (INFINITY !=fabs(nIm)))
          {
            outStream->pBuf[j].re += nReN;
            outStream->pBuf[j].im += nIm;
          }
        }
      }
      else
      {
        retErr = ERR_INV_CHANNEL_TYPE;
      }
    }
    else
    {
      retErr = ERR_INV_BUFFER_SIZE;
    }
  }
  else
  {
    retErr = ERR_INV_NULL_POINTER;
  }

  return Error_HandleErr(retErr);
}



/*************************/
/*** PRIVATE FUNCTIONS ***/
/*************************/

/**
 * @brief <i> Function for estimating the average power of a complex stream. </i>
 * 
 * @param[in] inStream input stream
 * 
 * @return signal linea average power
 */
static float GetComplexSgnPower( const complex_stream_t * inStream )
{
  Debug_SetWatermark((void *)GetComplexSgnPower,WM_LEVEL_2);

  float energy = 0;
  ulen_t j;

  for (j=0; j<inStream->len; j++)
  {
    energy += inStream->pBuf[j].re*inStream->pBuf[j].re+ \
              inStream->pBuf[j].im*inStream->pBuf[j].im;
  }

  return (energy/inStream->len);
}
