
#ifndef UTEST_MODULATION_H
#define	UTEST_MODULATION_H

int run_modulation_tests(void);

#endif	
