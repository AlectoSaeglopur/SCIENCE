var searchData=
[
  ['ebn0_0',['EbN0',['../struct__chan__par__t.html#af3457e59e9d1d95e1b6d14ba79edb574',1,'_chan_par_t']]],
  ['elapsedtime_1',['elapsedTime',['../main_8c.html#abb0e0fa240bd61376c8f39831094ab22',1,'main.c']]]
];
