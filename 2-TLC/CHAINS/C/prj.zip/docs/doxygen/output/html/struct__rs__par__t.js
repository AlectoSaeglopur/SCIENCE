var struct__rs__par__t =
[
    [ "dimGF", "struct__rs__par__t.html#a2b1bd9f87f5775304bb512f453c86225", null ],
    [ "kSh", "struct__rs__par__t.html#adb05b3d2eae120bfa09d2a4a72c59c0a", null ],
    [ "kUn", "struct__rs__par__t.html#af74f839e7921b35f99f04197cd016a8f", null ],
    [ "m", "struct__rs__par__t.html#a1214341262f4e73f2df90fac456c691c", null ],
    [ "nSh", "struct__rs__par__t.html#adcc3369d6073be7c320c286deb4b7251", null ],
    [ "nUn", "struct__rs__par__t.html#ab53837258d2b421a9388c53f5a2eb26d", null ],
    [ "t", "struct__rs__par__t.html#a2d03918f4f9edabaf3c9f43abcc2d85b", null ]
];