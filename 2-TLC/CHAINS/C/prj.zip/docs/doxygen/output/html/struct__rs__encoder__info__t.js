var struct__rs__encoder__info__t =
[
    [ "lenPrimPoly", "struct__rs__encoder__info__t.html#a37265ac3f88167f19ddbb4c1daf84c78", null ],
    [ "pPrimPoly", "struct__rs__encoder__info__t.html#abb09e54d2e0607a8ac23c9b20cdaf5c6", null ]
];