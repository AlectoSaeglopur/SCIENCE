var struct__rs__encoder__info__t =
[
    [ "lenPrimPoly", "struct__rs__encoder__info__t.html#a37265ac3f88167f19ddbb4c1daf84c78", null ]
];