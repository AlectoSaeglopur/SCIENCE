var struct__debug__par__t =
[
    [ "ccPar", "struct__debug__par__t.html#a8be480330b6dc83df7b383569d763634", null ],
    [ "chanPar", "struct__debug__par__t.html#a513e79f95ad6a12467cb8d15be7cf346", null ],
    [ "itlvPar", "struct__debug__par__t.html#a794cca30a246cda8dff05a41b73e68ca", null ],
    [ "modPar", "struct__debug__par__t.html#a61f1928d9c6018c3b92f80ad2036e7ab", null ],
    [ "rsPar", "struct__debug__par__t.html#a84a643563d469e45b815eed1108872db", null ],
    [ "scrPar", "struct__debug__par__t.html#a65b5d066e822f7b583331bccb55457de", null ]
];