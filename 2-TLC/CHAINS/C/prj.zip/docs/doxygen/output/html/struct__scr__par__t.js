var struct__scr__par__t =
[
    [ "conVect", "struct__scr__par__t.html#a8d48153076dc2c4cae2ede7a2f48651b", null ],
    [ "initSt", "struct__scr__par__t.html#a6d01c3566070bc9aff665aef7b531986", null ],
    [ "nCells", "struct__scr__par__t.html#a1901899780912ce6c43cff26f0625ef3", null ],
    [ "type", "struct__scr__par__t.html#a8b9d16760f0f06a79f75d0e7c501d28f", null ]
];