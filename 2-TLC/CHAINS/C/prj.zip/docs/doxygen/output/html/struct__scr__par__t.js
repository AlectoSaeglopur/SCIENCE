var struct__scr__par__t =
[
    [ "conVect", "struct__scr__par__t.html#a8d48153076dc2c4cae2ede7a2f48651b", null ],
    [ "initSt", "struct__scr__par__t.html#a6d01c3566070bc9aff665aef7b531986", null ]
];