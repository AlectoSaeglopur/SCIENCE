var searchData=
[
  ['rs_5fgf_5fdegree_5f8_0',['RS_GF_DEGREE_8',['../reed__solomon_8h.html#a4e768562ae0f0da6d9705ffad235a3a6a9a8334c9c8b675860f4b006c7a06b547',1,'reed_solomon.h']]],
  ['rs_5ftable_5fidx_5fnum_1',['RS_TABLE_IDX_NUM',['../reed__solomon_8c.html#aaef0cc8a068838e1390996f7f7b42222abb3443a499e474497a43fe2a63daa524',1,'reed_solomon.c']]],
  ['rs_5ftable_5fidx_5fsym_2',['RS_TABLE_IDX_SYM',['../reed__solomon_8c.html#aaef0cc8a068838e1390996f7f7b42222a099d3b6bc81596c5fbe0b0f73fec9239',1,'reed_solomon.c']]]
];
