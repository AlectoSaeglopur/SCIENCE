var struct__chan__par__t =
[
    [ "bps", "struct__chan__par__t.html#a1eeec50969596a3dee67341cac858bce", null ],
    [ "EbN0", "struct__chan__par__t.html#af3457e59e9d1d95e1b6d14ba79edb574", null ],
    [ "Peb", "struct__chan__par__t.html#a7279be27f151a19954235801d5273892", null ],
    [ "seed", "struct__chan__par__t.html#a7a3a89c2bc797e681ec9d4867aa39a5f", null ],
    [ "type", "struct__chan__par__t.html#afdb071716e1751d8416d20c71174a2e9", null ]
];