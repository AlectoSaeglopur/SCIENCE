var crc_8h =
[
    [ "_crc_par_t", "struct__crc__par__t.html", null ],
    [ "CRC_DEGREE", "crc_8h.html#af4276510cedd81f5df4887aa841fbf6e", null ],
    [ "crc_degree_t", "crc_8h.html#a6101862234971a20f6ea322793d0e81f", [
      [ "CRC_DEGREE_8", "crc_8h.html#a6101862234971a20f6ea322793d0e81fabbeb4073f7e0f28e341ebda4798b6785", null ],
      [ "CRC_DEGREE_16", "crc_8h.html#a6101862234971a20f6ea322793d0e81fa948aabaa84cc1f8672b8cf7e4ed577df", null ],
      [ "CRC_DEGREE_24", "crc_8h.html#a6101862234971a20f6ea322793d0e81fad82c48395597caa4c6d6801c5303f723", null ],
      [ "CRC_DEGREE_32", "crc_8h.html#a6101862234971a20f6ea322793d0e81fa9445290f6e06f33f45b5cb8f35123a41", null ],
      [ "CRC_DEGREE_64", "crc_8h.html#a6101862234971a20f6ea322793d0e81fa4ffb0292a6735033741c5c522fd0af07", null ]
    ] ],
    [ "Crc_CalculateChecksum", "crc_8h.html#a241be4cb5484b5e5d27c6a54f8064b52", null ],
    [ "Crc_ListParameters", "crc_8h.html#ae9c2527beb76e21bf308003d0aebec41", null ]
];