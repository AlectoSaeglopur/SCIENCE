var struct__crc__par__t =
[
    [ "degree", "struct__crc__par__t.html#a61c025789cac31024a8fc6030a579e4e", null ],
    [ "lenGenPoly", "struct__crc__par__t.html#a5bef7aee179d6746ad992c92dba73b4c", null ],
    [ "pGenPoly", "struct__crc__par__t.html#a88b10729102ef31d6c73bff972f6315a", null ]
];