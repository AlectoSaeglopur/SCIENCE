var channel_8c =
[
    [ "Channel_AWGN", "channel_8c.html#a7fbdb35e62e6f7572b56acee57350263", null ],
    [ "Channel_BSC", "channel_8c.html#a447fb3627e3adb47767913e12783c552", null ],
    [ "Channel_ListParameters", "channel_8c.html#afd34dc089fd01a3617342289200cef93", null ],
    [ "GetComplexSgnPower", "channel_8c.html#af55bec4125c79407eab0e283468a018b", null ]
];