var reed__solomon_8h =
[
    [ "_rs_par_t", "struct__rs__par__t.html", "struct__rs__par__t" ],
    [ "CODEWORD_SIZE", "reed__solomon_8h.html#a49419cff0869dbe4725bc86b04d93d91", null ],
    [ "GF_DEGREE", "reed__solomon_8h.html#a07f2d43f7b78f970672b81b20a552645", null ],
    [ "MESSAGE_SIZE", "reed__solomon_8h.html#aeca90e1c1c62b70670514ffc18c9dfd4", null ],
    [ "rs_gf_degree_t", "reed__solomon_8h.html#a4e768562ae0f0da6d9705ffad235a3a6", [
      [ "RS_GF_DEGREE_4", "reed__solomon_8h.html#a4e768562ae0f0da6d9705ffad235a3a6a5cc9e5e77769f4cdc70e14ec1b3343e2", null ],
      [ "RS_GF_DEGREE_8", "reed__solomon_8h.html#a4e768562ae0f0da6d9705ffad235a3a6a9a8334c9c8b675860f4b006c7a06b547", null ]
    ] ],
    [ "RcCod_Decoder", "reed__solomon_8h.html#a213eec64045f18379405efd4b2e19d3d", null ],
    [ "RcCod_Encoder", "reed__solomon_8h.html#a8d0400ebf3aceca73c08b1b1a8e67808", null ],
    [ "RsCod_ListParameters", "reed__solomon_8h.html#a578373b27d35cdf390538bf58e3d7a54", null ]
];