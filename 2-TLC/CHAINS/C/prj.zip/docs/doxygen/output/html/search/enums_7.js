var searchData=
[
  ['rs_5fgf_5fdegree_5ft_0',['rs_gf_degree_t',['../reed__solomon_8h.html#a4e768562ae0f0da6d9705ffad235a3a6',1,'reed_solomon.h']]],
  ['rs_5ftable_5fidx_5ft_1',['rs_table_idx_t',['../reed__solomon_8c.html#aaef0cc8a068838e1390996f7f7b42222',1,'reed_solomon.c']]]
];
