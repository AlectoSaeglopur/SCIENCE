var struct__complex__stream__t =
[
    [ "id", "struct__complex__stream__t.html#a4f594557c7bb22a63850dd55ce9a0bf6", null ],
    [ "len", "struct__complex__stream__t.html#ac4fa45596f6036abae4a915399644b76", null ]
];