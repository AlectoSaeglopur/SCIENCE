var crc_8c =
[
    [ "Crc_CalculateChecksum", "crc_8c.html#a241be4cb5484b5e5d27c6a54f8064b52", null ],
    [ "Crc_ListParameters", "crc_8c.html#ae9c2527beb76e21bf308003d0aebec41", null ],
    [ "FindMaxDegree", "crc_8c.html#a783e51dc59c6af0b19080bc7619116f2", null ],
    [ "CRC_GENPOLY_16", "crc_8c.html#a8b9e01a47fffb0ca2fdb05321177b8de", null ],
    [ "CRC_GENPOLY_24", "crc_8c.html#a156d4fb178d6c565b3bccdda68d64a41", null ],
    [ "CRC_GENPOLY_32", "crc_8c.html#a0c728eac03e124969d13b3e75b3e72cc", null ],
    [ "CRC_GENPOLY_64", "crc_8c.html#a5bab8084de9f739f4b4a98868929d9a4", null ],
    [ "CRC_GENPOLY_8", "crc_8c.html#a6c76f963ce032d8946a7515f314d30a6", null ]
];