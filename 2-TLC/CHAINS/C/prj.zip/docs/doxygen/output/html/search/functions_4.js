var searchData=
[
  ['error_5fhandleerr_0',['Error_HandleErr',['../error_8c.html#a75ff6944f6d43955f10838a9bd3edaae',1,'Error_HandleErr(error_t inErr):&#160;error.c'],['../error_8h.html#a75ff6944f6d43955f10838a9bd3edaae',1,'Error_HandleErr(error_t inErr):&#160;error.c']]],
  ['errorcorrector_1',['ErrorCorrector',['../reed__solomon_8c.html#a8ad8b51b3c078ea460f1934fdcbb943c',1,'reed_solomon.c']]],
  ['estimateeuclideandist_2',['EstimateEuclideanDist',['../convolutional_8c.html#a3b5a4a4688dc11fe44bcc625cd77c822',1,'convolutional.c']]]
];
