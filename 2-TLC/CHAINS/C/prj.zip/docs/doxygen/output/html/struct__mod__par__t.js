var struct__mod__par__t =
[
    [ "bps", "struct__mod__par__t.html#a1eeec50969596a3dee67341cac858bce", null ],
    [ "order", "struct__mod__par__t.html#aa44597f38af03f4bb6ef069ba7efb24c", null ],
    [ "phOfst", "struct__mod__par__t.html#a68e304f9c957a11acbf769ae9cbc707f", null ]
];