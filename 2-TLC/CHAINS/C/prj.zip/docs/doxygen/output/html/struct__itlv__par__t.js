var struct__itlv__par__t =
[
    [ "cells", "struct__itlv__par__t.html#aab205f3c886634a40811f44385e0ff25", null ],
    [ "cols", "struct__itlv__par__t.html#ad20729054c5a93d34b65004b77d83262", null ],
    [ "dlys", "struct__itlv__par__t.html#a8179444a8520e4507704d96d58d0df8e", null ],
    [ "rows", "struct__itlv__par__t.html#adaa1a9f8ec83339cdb661714f5bd2c97", null ],
    [ "type", "struct__itlv__par__t.html#aa88bff9e4cbd7526c284ee51744f5e6f", null ]
];