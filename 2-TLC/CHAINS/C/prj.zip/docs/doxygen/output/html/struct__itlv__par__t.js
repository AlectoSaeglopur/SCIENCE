var struct__itlv__par__t =
[
    [ "cells", "struct__itlv__par__t.html#aab205f3c886634a40811f44385e0ff25", null ],
    [ "dlys", "struct__itlv__par__t.html#a8179444a8520e4507704d96d58d0df8e", null ]
];