var annotated_dup =
[
    [ "_byte_stream_t", "struct__byte__stream__t.html", "struct__byte__stream__t" ],
    [ "_cc_encoder_info_t", "struct__cc__encoder__info__t.html", "struct__cc__encoder__info__t" ],
    [ "_cc_hard_dec_info_t", "struct__cc__hard__dec__info__t.html", "struct__cc__hard__dec__info__t" ],
    [ "_cc_par_t", "struct__cc__par__t.html", "struct__cc__par__t" ],
    [ "_cc_soft_dec_info_t", "struct__cc__soft__dec__info__t.html", "struct__cc__soft__dec__info__t" ],
    [ "_cc_trcore_t", "struct__cc__trcore__t.html", "struct__cc__trcore__t" ],
    [ "_cc_trellis_t", "struct__cc__trellis__t.html", "struct__cc__trellis__t" ],
    [ "_chan_par_t", "struct__chan__par__t.html", "struct__chan__par__t" ],
    [ "_complex_stream_t", "struct__complex__stream__t.html", "struct__complex__stream__t" ],
    [ "_complex_t", "struct__complex__t.html", "struct__complex__t" ],
    [ "_crc_par_t", "struct__crc__par__t.html", "struct__crc__par__t" ],
    [ "_debug_par_t", "struct__debug__par__t.html", "struct__debug__par__t" ],
    [ "_float_stream_t", "struct__float__stream__t.html", "struct__float__stream__t" ],
    [ "_itlv_par_t", "struct__itlv__par__t.html", "struct__itlv__par__t" ],
    [ "_mod_maptable_t", "struct__mod__maptable__t.html", "struct__mod__maptable__t" ],
    [ "_mod_par_t", "struct__mod__par__t.html", "struct__mod__par__t" ],
    [ "_rs_encoder_info_t", "struct__rs__encoder__info__t.html", "struct__rs__encoder__info__t" ],
    [ "_rs_par_t", "struct__rs__par__t.html", "struct__rs__par__t" ],
    [ "_scr_par_t", "struct__scr__par__t.html", "struct__scr__par__t" ]
];