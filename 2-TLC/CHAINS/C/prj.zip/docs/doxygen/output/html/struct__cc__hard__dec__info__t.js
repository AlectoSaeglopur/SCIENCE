var struct__cc__hard__dec__info__t =
[
    [ "dist", "struct__cc__hard__dec__info__t.html#aa70d161c3fd98317d9bd09065c36c460", null ],
    [ "path", "struct__cc__hard__dec__info__t.html#ae87f5a1e9c81c570bf0635777aa33c54", null ]
];