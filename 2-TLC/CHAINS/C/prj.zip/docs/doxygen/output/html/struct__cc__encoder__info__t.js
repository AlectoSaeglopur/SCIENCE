var struct__cc__encoder__info__t =
[
    [ "lenConnVect", "struct__cc__encoder__info__t.html#a9f7db4c6cface65b066c4211fe28c22e", null ],
    [ "lenPuncVect", "struct__cc__encoder__info__t.html#a6c4a829550c5748162148fba727e9069", null ],
    [ "pPuncVect", "struct__cc__encoder__info__t.html#a4b4221fd253787f4493e114c352e8e5f", null ]
];