var struct__cc__par__t =
[
    [ "cRate", "struct__cc__par__t.html#aa9f6352e123f7cb76dfbadbf39a2f875", null ],
    [ "kLen", "struct__cc__par__t.html#a924a2177d10271f6b883f7c51f55a87b", null ],
    [ "memFact", "struct__cc__par__t.html#abfd757054a6ded54f06b750de0c3b882", null ],
    [ "vitDM", "struct__cc__par__t.html#a943ee5c9ebe93c1a18dd954094e0067f", null ]
];