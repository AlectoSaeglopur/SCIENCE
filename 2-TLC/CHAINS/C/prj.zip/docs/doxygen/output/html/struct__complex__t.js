var struct__complex__t =
[
    [ "im", "struct__complex__t.html#a967065f052e06d0e239b9bc56e0cc317", null ],
    [ "re", "struct__complex__t.html#aeac685ede53ad58d0e24e6c060feff7a", null ]
];