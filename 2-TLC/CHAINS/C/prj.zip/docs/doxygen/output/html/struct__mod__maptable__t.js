var struct__mod__maptable__t =
[
    [ "bits", "struct__mod__maptable__t.html#aabb8fae3119b1cb4df366525f58ff392", null ],
    [ "symbs", "struct__mod__maptable__t.html#a5066361b9b5889cb676e172961b7f980", null ]
];