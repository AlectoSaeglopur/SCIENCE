var searchData=
[
  ['cc_5fdec_5fmethod_5ft_490',['cc_dec_method_t',['../convolutional_8h.html#ab6bf5dd3ca66fd4dcdb8839ae87fc113',1,'convolutional.h']]],
  ['cc_5fklen_5ft_491',['cc_klen_t',['../convolutional_8h.html#a38de18fffd75ccef7581a78855684da3',1,'convolutional.h']]],
  ['chan_5ftype_5ft_492',['chan_type_t',['../channel_8h.html#afe350c7813c36d532a69cfc851076544',1,'channel.h']]],
  ['crc_5fdegree_5ft_493',['crc_degree_t',['../crc_8h.html#a6101862234971a20f6ea322793d0e81f',1,'crc.h']]]
];
