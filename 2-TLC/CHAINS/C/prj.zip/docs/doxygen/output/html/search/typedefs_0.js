var searchData=
[
  ['ansi_5ftext_5fcolor_0',['ansi_text_color',['../debug_8h.html#af985040572d5ac5b732b8243ad3fb495',1,'debug.h']]],
  ['ansi_5ftext_5fstyle_1',['ansi_text_style',['../debug_8h.html#a65ebce3ee05a977a17b97d961de90391',1,'debug.h']]]
];
